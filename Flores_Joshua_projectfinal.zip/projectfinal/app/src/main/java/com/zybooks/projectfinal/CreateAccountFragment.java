package com.zybooks.projectfinal;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import java.sql.DatabaseMetaData;
import java.util.List;

public class CreateAccountFragment extends Fragment implements View.OnClickListener{
    EditText textUsername, textPassword, textEmail;
    Button addAcount, viewALl;
    View view;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        view = inflater.inflate(R.layout.fragment_create_account, container, false);

        initView();



        return view;
    }

    private void initView(){

        textPassword = (EditText) view.findViewById(R.id.editTextTextPassword);
        textUsername = (EditText) view.findViewById(R.id.editTextTextPersonName);
        textEmail = (EditText) view.findViewById(R.id.editTextTextEmailAddress);
        addAcount = view.findViewById(R.id.finishCreateAccountBtn);
        viewALl = view.findViewById(R.id.viewAll);
        viewALl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DBHelper dbHelper = new DBHelper(getContext());
                List<User> everyUser = dbHelper.getAllUsers();
                Toast.makeText(getContext(), everyUser.toString(), Toast.LENGTH_SHORT).show();
            }
        });
        addAcount.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        User newUser;
        try{
            newUser = new User(textEmail.getText().toString(), textUsername.getText().toString(),textPassword.getText().toString());
        }catch(Exception e){
            Toast.makeText(getContext(), "Error making user", Toast.LENGTH_SHORT).show();
            newUser = new User("error", "error", "error");
        }

        DBHelper dbHelper = new DBHelper(getContext());

        boolean success = dbHelper.insertUserData(newUser);

        Toast.makeText(getContext(), "Sucess = " + success, Toast.LENGTH_SHORT).show();
    }
}