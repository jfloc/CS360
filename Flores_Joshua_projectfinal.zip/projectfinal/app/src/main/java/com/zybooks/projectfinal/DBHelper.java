package com.zybooks.projectfinal;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;


import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "userdata.db";
    private static final int VERSION = 1;

    public DBHelper(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class UserTable{
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_EMAIL = "email";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + UserTable.TABLE + "(" +
                UserTable.COL_ID + " integer primary key autoincrement, " +
                UserTable.COL_EMAIL + " text, " +
                UserTable.COL_USERNAME + " text, " +
                UserTable.COL_PASSWORD + " text) ");
    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int oldVersion, int newVersion) {
        DB.execSQL("drop Table if exists Userdetails");
    }

    public Boolean insertUserData(User user)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(UserTable.COL_EMAIL , user.getEmail());
        contentValues.put(UserTable.COL_USERNAME, user.getUsername());
        contentValues.put(UserTable.COL_PASSWORD, user.getUserPassword());
        long result = DB.insert(UserTable.TABLE,null, contentValues);

        return result != -1;
    }

    public List<User> getAllUsers(){

        List<User> returnList = new ArrayList<>();

        String queryString = "SELECT * FROM " + UserTable.TABLE;

        SQLiteDatabase db =  this.getReadableDatabase();

        Cursor cursor = db.rawQuery(queryString, null);
        if(cursor.moveToFirst()){
            // loop through the cursor(result set)and create new user objects. put them in a retunList.
            do{
                String email = cursor.getString(1);
                String username = cursor.getString(2);
                String password = cursor.getString(3);

                User newUser = new User(email,username,password);
                returnList.add(newUser);

            }while(cursor.moveToNext());
        }else{
            //nothing
        }

        cursor.close();
        db.close();
        return returnList;
    }

    public User getUser(Context context, String userName){
        SQLiteDatabase db = this.getReadableDatabase();
        String queryString = "SELECT * FROM " + UserTable.TABLE + " WHERE " + UserTable.COL_USERNAME + " = ? ";
        Cursor cursor = db.rawQuery(queryString, new String[]{userName});

        User currentUser = new User("null email","null user","null pass");
        if(cursor.moveToFirst()){
            do{
                String email = cursor.getString(1);
                String user = cursor.getString(2);
                String pass = cursor.getString(3);

                if(userName.equals(user)){
                    currentUser.setUsername(user);
                    currentUser.setUserPassword(pass);
                    currentUser.setEmail(email);
                }
            }while(cursor.moveToNext());
        }

        cursor.close();
        db.close();

        return currentUser;
    }

    public boolean findUserInDB(Context context, String username, String password){

        SQLiteDatabase db =  this.getReadableDatabase();
        String queryString = "SELECT * FROM " + UserTable.TABLE + " WHERE " + UserTable.COL_USERNAME + " = ? ";
        Cursor cursor = db.rawQuery(queryString, new String[]{username});

        if(cursor.moveToFirst()){
            do {

                String user = cursor.getString(2);
                String pass = cursor.getString(3);
                if(username.equals(user) && pass.equals(password) ){
                    return true;
                }
                else if(username.equals(user)) {
                    Toast.makeText(context, "wrong password", Toast.LENGTH_SHORT).show();
                }

            }while (cursor.moveToNext());
        }

        cursor.close();
        db.close();

        Toast.makeText(context, "No user found", Toast.LENGTH_SHORT).show();
        return false;
    }
}
