package com.zybooks.projectfinal;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DBWeightHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weights.db";
    private static final int VERSION = 1;

    public DBWeightHelper(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class WeightTable{
        private static final String TABLE = "weighttable";
        private static final String COL_DAY = "_id";
        private static final String COL_WEIGHT = "weights";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + WeightTable.TABLE + "(" +
                WeightTable.COL_DAY + " integer primary key autoincrement, " +
                WeightTable.COL_WEIGHT + " text) ");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop Table if exists Userdetails");
    }

    public Boolean insertUserData(String weightString)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(WeightTable.COL_WEIGHT,weightString);
        long result = db.insert(WeightTable.TABLE,null,contentValues);

        return result != -1;

    }

    public List<String> viewAllWeights(){

        List<String> weightLists = new ArrayList<>();

        String queryString = "SELECT * FROM " + WeightTable.TABLE;

        SQLiteDatabase db =  this.getReadableDatabase();
        Cursor cursor = db.rawQuery(queryString, null);

        if(cursor.moveToFirst()){
            // loop through the cursor(result set)and create new user objects. put them in a retunList.
            do{
                String weight = cursor.getString(1);
                weightLists.add(weight);
            }while(cursor.moveToNext());
        }else{
            //nothing
        }

        cursor.close();
        db.close();
        return weightLists;
    }
}
