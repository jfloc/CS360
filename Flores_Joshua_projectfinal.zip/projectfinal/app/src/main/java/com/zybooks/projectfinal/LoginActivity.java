package com.zybooks.projectfinal;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity {
    GraphView graphView;
    ImageButton notificationButton;
    Button weightJournalBttn;
    View journalMainView;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.graph_layout);

        Intent intent = getIntent();
        String userName= intent.getStringExtra("USER_NAME");

        graphView = findViewById(R.id.idGraphView);
        notificationButton = findViewById(R.id.imageButton);
        weightJournalBttn = findViewById(R.id.weight_journal_button);

        DBHelper dbHelper = new DBHelper(this);

        User currentUser = dbHelper.getUser(this, userName);


        DBWeightHelper dbWeightHelper = new DBWeightHelper(LoginActivity.this);

        ArrayList<Double> weights = new ArrayList<>();
        try{

            for(String s: dbWeightHelper.viewAllWeights() ){
                weights.add(Double.parseDouble(s));
            }


        }catch (Exception e){
            Toast.makeText(this,"Something went wrong, check graph data is inserted.", Toast.LENGTH_SHORT).show();
        }
        ArrayList<DataPoint> dataPoints = new ArrayList<>();
        for(int i = 0; i < weights.size(); i++){
            DataPoint dataPoint = new DataPoint(i,weights.get(i));
            dataPoints.add(dataPoint);
        }
        DataPoint[] dataPointArray = new DataPoint[dataPoints.size()];
        for(int i = 0; i < dataPointArray.length; i++){
            dataPointArray[i] = dataPoints.get(i);
        }

        LineGraphSeries<DataPoint> series = new LineGraphSeries<DataPoint>(dataPointArray);


        graphView.setTitle("Weight graph");
        graphView.setTitleColor(android.R.color.holo_red_dark);
        graphView.setTitleTextSize(18);
        graphView.addSeries(series);


        notificationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);
                builder.setTitle("Notification Settings");
                builder.setMessage("Do you want to turn notifications on or off?");

                builder.setPositiveButton("On", (dialogInterface, i) -> {
                });
                builder.setNegativeButton("Off", (dialogInterface, i) -> {
                });

                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        weightJournalBttn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), WeightJournalActivity.class);
                intent.putExtra("USER_NAME", userName);
                startActivity(intent);
            }
        });

    }
}
