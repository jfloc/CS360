package com.zybooks.projectfinal;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class LoginMenuFragment extends Fragment {
    EditText etUser, etPassword;
    View fragmentView;
    public Button createAccount, loginButton;

    @Override
    public void onCreate(Bundle savedInstance){
        super.onCreate(savedInstance);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        fragmentView = inflater.inflate(R.layout.fragment_login_menu, container, false);

        createAccount = fragmentView.findViewById(R.id.createAccountButton);

        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment fragment = new CreateAccountFragment();
                FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction().addToBackStack(null);
                fragmentTransaction.add(R.id.fragmentContainerView, fragment).commit();
            }
        });

        etUser = fragmentView.findViewById(R.id.usernameEditText);
        etPassword = fragmentView.findViewById(R.id.passwordEditText);
        loginButton = fragmentView.findViewById(R.id.loginButton);

        loginButton.setOnClickListener(buttonClickListener);

        return fragmentView;
    }

    public interface OnLoginButtonClickedListener{
        void onLoginButtonClicked(boolean loggedIn, String userName);
    }

    OnLoginButtonClickedListener mListener;

    @Override
    public void onAttach(Context context){
        super.onAttach(context);
        if(context instanceof OnLoginButtonClickedListener){
            mListener = (OnLoginButtonClickedListener) context;
        }else{
            throw new RuntimeException(context.toString()
                    + " must implement OnLoginButtonClickedListener");
        }
    }

    public void OnDetach(){
        super.onDetach();
        mListener = null;
    }

    private View.OnClickListener buttonClickListener = new View.OnClickListener(){
        @Override
        public void onClick(View view){
            DBHelper dbHelper = new DBHelper(getContext());
            try {
                String user = etUser.getText().toString();
                String pass = etPassword.getText().toString();

                boolean passed = dbHelper.findUserInDB(getContext(),user,pass);
                mListener.onLoginButtonClicked(passed,user);

            }catch (Exception e){
                Toast.makeText(getContext(), "Error not found", Toast.LENGTH_SHORT).show();
            }
        }
    };

}
