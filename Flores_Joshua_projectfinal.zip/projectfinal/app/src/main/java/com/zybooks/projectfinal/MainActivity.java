package com.zybooks.projectfinal;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements LoginMenuFragment.OnLoginButtonClickedListener {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        LoginMenuFragment fragment = new LoginMenuFragment();
        fragmentTransaction.add(R.id.fragmentContainerView,fragment).addToBackStack(null);
        fragmentTransaction.commit();

    }


    @Override
    public void onLoginButtonClicked(boolean loggedIn, String username) {

        Intent intent = new Intent(this, LoginActivity.class);
        intent.putExtra("USER_NAME", username);
        if(loggedIn) startActivity(intent);

    }
}