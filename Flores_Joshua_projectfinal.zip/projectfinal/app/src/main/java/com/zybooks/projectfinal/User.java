package com.zybooks.projectfinal;

import java.util.ArrayList;

public class User {
    private String email;
    private String username;
    private String userPassword;
    private ArrayList<String> weights;
    User(String email, String usernameIn, String passwordIn, ArrayList<String> weightsIn){
        this.email = email;
        this.username = usernameIn;
        this.userPassword = passwordIn;
        this.weights = weightsIn;
    }
    User(String emailIn, String usernameIn, String passwordIn){
            this.username = usernameIn;
            this.userPassword = passwordIn;
            this.weights = new ArrayList<>();
            this.email = emailIn;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public ArrayList<String> getWeights() {
        return weights;
    }

    public void setWeights(ArrayList<String> weights) {
        this.weights = weights;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail(){return this.email; }

    public void setEmail(String emailIn){this.email = emailIn; }

    public String toString(){
        StringBuilder userInfo = new StringBuilder();
        userInfo.append(this.getEmail()).append("/").append(this.getUsername()).append("/").append(this.getUserPassword()).append("/");
        if(!(this.getWeights().isEmpty())) {
            for (String weights : this.getWeights()) {
                userInfo.append(weights).append(",");
            }
        }
        userInfo.append('\n');
        return userInfo.toString();
    }
}
