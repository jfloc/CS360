package com.zybooks.projectfinal;
import android.content.Context;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class UserDatabase {
    private Set<User> userSet;

    UserDatabase(Context context) throws IOException {
        String userSetString = readFromInternalFile(context);
        if(!(userSetString.equals("not found"))){
            this.userSet = getUserSet(userSetString);
        }else{
            this.userSet = new HashSet<>();
        }
    }

    public void addUser(Context context, User addUser){
        if(!(userSet.contains(addUser))){
            this.userSet.add(addUser);
        }else{
            Toast.makeText(context,"Username already in use", Toast.LENGTH_LONG).show();
        }
    }

    private void writeToInternalFile(Context context, User user) throws IOException {
        FileOutputStream outputStream = context.openFileOutput("userData.data", Context.MODE_PRIVATE);
        PrintWriter writer = new PrintWriter(outputStream);
        writer.println(user.toString());
        writer.close();
    }

    private ArrayList<String> createArrayListWeights(String weightString){
        ArrayList<String> weights = new ArrayList<>();
        StringBuilder currWeight = new StringBuilder();
        for(char c: weightString.toCharArray()){
            if(c != ','){
                currWeight.append(c);
            }else{
                weights.add(currWeight.toString());
                currWeight = new StringBuilder();
            }
        }

        return weights;
    }

    private User createUserFromString(String userCreateString){
        String email ="", userName="", password="", weights="";
        int count = 0;
        for(char c: userCreateString.toCharArray()){
            if(c == '/'){
                count++;
            }else {
                switch (count) {
                    case 0:
                        email += c;
                    break;
                    case 1:
                        userName += c;
                        break;
                    case 2:
                        password += c;
                        break;
                    case 3:
                        weights += c;
                        break;
                }
            }
        }
        ArrayList<String> weightsForUser = createArrayListWeights(weights);
        return new User(email,userName,password,weightsForUser);
    }

    public Set<User> getUserSet(String userSetString){
        Scanner scanner = new Scanner(userSetString);
        Set<User> newUserSet = new HashSet<>();

        while(scanner.hasNextLine()){
            String line = scanner.nextLine();
           // allah hu akbar allah hu akbar
            User user = createUserFromString(line);
            newUserSet.add(user);
        }

        return newUserSet;
    }

    private String readFromInternalFile(Context context) throws IOException {
        FileInputStream inputStream = context.openFileInput("userData.data");

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
            String line;
            StringBuilder stringBuilder = new StringBuilder();

            while (((line = reader.readLine()) != null)) {
                stringBuilder.append(line);
            }

            return stringBuilder.toString();
        }catch (Error error){
            return ("not found");
        }
    }
    private String findUserInFile(Context context, String user) throws IOException {
        FileInputStream inputStream = context.openFileInput("userData.data");

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
            String line;
            StringBuilder stringBuilder = new StringBuilder();

            boolean userFound = false;
            while (((line = reader.readLine()) != null) && !userFound) {
                stringBuilder.append(line);
                int count = 0;
                StringBuilder dataPiece = new StringBuilder();
                for(char c: line.toCharArray()){ // userName / Password / 128,323,542

                    if(c == '/' && (user.toLowerCase().equals(dataPiece.toString().toLowerCase()))){
                        userFound = true;

                    }
                    dataPiece.append(c);
                }
                stringBuilder = dataPiece;
            }

            if(!userFound){
                return "user not found";
            }

            return stringBuilder.toString();
        }
    }


}
