package com.zybooks.projectfinal;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class WeightJournalActivity extends AppCompatActivity {
    EditText addWeightLine;
    Button addWeight, editWeight, deleteWeight, viewWeights;
    boolean turnVisible = false;
    int count = 0;

    @Override
    protected void onCreate(Bundle savedInstance){
        super.onCreate(savedInstance);
        setContentView(R.layout.update_layout);

        Intent intent = getIntent();
        String userName = intent.getStringExtra("USER_NAME");

        addWeightLine = (EditText) findViewById(R.id.add_weight_line);
        addWeightLine.setVisibility(View.INVISIBLE);

        viewWeights = findViewById(R.id.view_weights);
        addWeight = findViewById(R.id.add_weight_button);
        editWeight = findViewById(R.id.edit_weight_button);
        deleteWeight = findViewById(R.id.delete_weight_button);





        addWeight.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {

                if(count % 2 == 0){
                    turnVisible = true;
                }else{
                    turnVisible = false;
                }

                count+= 1;

                if(turnVisible){
                    addWeightLine.setClickable(true);
                    addWeightLine.setVisibility(View.VISIBLE);
                }
                else{
                    String weights = addWeightLine.getText().toString();
                    DBWeightHelper dbWeightHelper = new DBWeightHelper(WeightJournalActivity.this);
                    try {
                        dbWeightHelper.insertUserData(weights);
                    }catch (Exception e){
                        Toast.makeText(WeightJournalActivity.this, "could not add weight", Toast.LENGTH_SHORT).show();
                    }
                    addWeightLine.setClickable(false);
                    addWeightLine.setVisibility(View.INVISIBLE);
                    addWeightLine.clearComposingText();
                }
            }

        });

        viewWeights.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DBWeightHelper dbWeightHelper = new DBWeightHelper(v.getContext());
                List<String> weightList = dbWeightHelper.viewAllWeights();

                Toast.makeText(WeightJournalActivity.this, weightList.toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }

}
