package com.zybooks.proj21;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

public class LoginActivity extends AppCompatActivity {
    GraphView graphView;
    ImageButton notificationButton;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.graph_layout);

        graphView = findViewById(R.id.idGraphView);
        notificationButton = findViewById(R.id.imageButton);

        LineGraphSeries<DataPoint> series = new LineGraphSeries<DataPoint>(new DataPoint[]{
                new DataPoint(0, 1),
                new DataPoint(1, 3),
                new DataPoint(2, 4),
                new DataPoint(3, 6),
                new DataPoint(4, 3)
        });

        graphView.setTitle("Weight graph");
        graphView.setTitleColor(android.R.color.holo_red_dark);
        graphView.setTitleTextSize(18);
        graphView.addSeries(series);


        notificationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //AlertDialog alertDialog = new AlertDialog();
            }
        });

    }

    public void onButtonClick(View view){
        Intent intent = new Intent(this, WeightJournalActivity.class);
        startActivity(intent);
    }
}
