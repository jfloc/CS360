package com.zybooks.proj21;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainMenuActivity extends AppCompatActivity {
    Button loginButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //loginButton = (Button)findViewById(R.id.loginButton);

//        loginButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                onClickButton();
//            }
//        });
    }

    public boolean usernameLoginPassed(){
        return true;
    }
    public void onClickButton(View view){
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        // boolean passed = usernameLoginPassed();
       /* if(passed){
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
        }else{
            Toast.makeText(this, "No user found", Toast.LENGTH_SHORT).show();
        }*/
    }
}