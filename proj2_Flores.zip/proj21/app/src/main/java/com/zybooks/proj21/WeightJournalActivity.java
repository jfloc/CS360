package com.zybooks.proj21;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

public class WeightJournalActivity extends AppCompatActivity {
    RecyclerView weightView;
    @Override
    protected void onCreate(Bundle savedInstance){
        super.onCreate(savedInstance);
        setContentView(R.layout.update_layout);


    }
}
